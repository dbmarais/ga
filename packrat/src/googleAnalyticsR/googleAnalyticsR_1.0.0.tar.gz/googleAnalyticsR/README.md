# googleAnalyticsR

![CRAN](https://www.r-pkg.org/badges/version/googleAnalyticsR)
[![codecov](https://codecov.io/gh/MarkEdmondson1234/googleAnalyticsR/branch/master/graph/badge.svg)](https://codecov.io/gh/MarkEdmondson1234/googleAnalyticsR)
[![CII Best Practices](https://bestpractices.coreinfrastructure.org/projects/2025/badge)](https://bestpractices.coreinfrastructure.org/projects/2025)
![CloudBuild](https://badger-ewjogewawq-ew.a.run.app/build/status?project=mark-edmondson-gde&id=4ae2fa13-b1d8-41f3-b846-8bf3c67f050a)
[![CodeFactor](https://www.codefactor.io/repository/github/markedmondson1234/googleanalyticsr/badge)](https://www.codefactor.io/repository/github/markedmondson1234/googleanalyticsr)

![](https://raw.githubusercontent.com/MarkEdmondson1234/googleAnalyticsR/master/inst/hexlogo/hex.png)

Get more examples and tutorials at the [googleAnalyticsR website](https://code.markedmondson.me/googleAnalyticsR/)

## Install

```r
install.packages("googleAnalyticsR")
```

### Development version off GitHub

```r
remotes::install_github("MarkEdmondson1234/googleAnalyticsR")
```
