# contents of a file
## ui.R ##
htmlTemplate(
  "template.html",
  auth_ui = {{ auth_ui }},
  date_range = {{{ date_range }}},
  model_ui = {{{ model_ui }}}
) 
