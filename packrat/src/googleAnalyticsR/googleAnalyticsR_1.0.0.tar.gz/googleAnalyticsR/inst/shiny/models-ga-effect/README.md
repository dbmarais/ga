This is an example of how to use `ga_model_*` functions to use a more complicated model, in this case one that uses CausalImpact to judge effects on SEO traffic.

Note the end code is the same as simpler models.  You can add more features such as drop downs and sliders as you require them to pass to the model.

