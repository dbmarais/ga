# Run a model online

    Code
      model2$shiny_module$ui("test")
    Output
      <div id="test-ui_out" class="shiny-plot-output" style="width:100%;height:400px;"></div>

