library(testthat)
library(googleAnalyticsR)

test_check("googleAnalyticsR")
