library(testthat)
library(measurementProtocol)

test_check("measurementProtocol")
